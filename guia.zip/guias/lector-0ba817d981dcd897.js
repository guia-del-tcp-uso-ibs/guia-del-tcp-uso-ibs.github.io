// El historial de los libros es independiente de la pestaña del simulador.
(() => {
  if (!document.documentElement.classList.contains('guia-integrada')) return;
  const volver = document.getElementById('volver-al-simulador');
  const afiliar = document.getElementById('afiliar-desde-guias');
  volver.addEventListener('click', () => parent.postMessage('guias:volver','*'));
  afiliar.addEventListener('click', () => parent.postMessage('guias:afiliar','*'));
  window.addEventListener('message', event => {
    if (event.source !== parent) return;
    if (event.data === 'guias:foco-afiliar') afiliar.focus({preventScroll:true});
    else if (event.data === 'guias:foco-volver') volver.focus({preventScroll:true});

  });
  parent.postMessage('guias:lista','*');
  document.addEventListener('click', event => {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) return;
    const enlace = event.target.closest('a[href^="#"]');
    if (!enlace || !document.getElementById(enlace.hash.slice(1))) return;
    event.preventDefault();
    location.replace(enlace.hash);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !event.defaultPrevented && !document.querySelector('dialog[open]')) {
      event.preventDefault();
      window.parent.postMessage('guias:volver', '*');
    }
  });
})();
