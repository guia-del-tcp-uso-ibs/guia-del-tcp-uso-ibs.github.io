// El historial de los libros es independiente de la pestaña del simulador.
(() => {
  if (!document.documentElement.classList.contains('guia-integrada')) return;
  const pasos = [];
  let restaurar;
  const volver = document.getElementById('volver-al-simulador');
  const afiliar = document.getElementById('afiliar-desde-guias');
  volver.addEventListener('click', () => parent.postMessage('guias:volver','*'));
  afiliar.addEventListener('click', () => parent.postMessage('guias:afiliar','*'));
  window.addEventListener('message', event => {
    if (event.source !== parent) return;
    if (event.data === 'guias:foco-afiliar') afiliar.focus({preventScroll:true});
    else if (event.data === 'guias:foco-volver') volver.focus({preventScroll:true});
    else if (event.data === 'guias:portada') {
      pasos.length = 0;
      restaurar = null;
      if (location.hash) {
        try { history.replaceState(history.state, '', location.href.split('#')[0]); }
        catch { location.replace('#inicio'); }
      }
      window.scrollTo(0, 0);
    }
  });
  parent.postMessage('guias:lista','*');
  document.addEventListener('click', event => {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) return;
    const enlace = event.target.closest('a[href^="#"]');
    if (!enlace || !document.getElementById(enlace.hash.slice(1))) return;
    event.preventDefault();
    const actual = location.hash || '#inicio';
    const anterior = enlace.classList.contains('return-arrow') && pasos.length ? pasos.pop() : null;
    const destino = anterior ? anterior.hash : enlace.hash;
    if (actual === destino) return;
    if (!anterior) pasos.push({hash: actual, scroll: window.scrollY, foco: enlace});
    restaurar = anterior;
    location.replace(destino);
  });
  window.addEventListener('hashchange', () => {
    if (!restaurar) return;
    const {scroll, foco} = restaurar;
    restaurar = null;
    if (foco.isConnected) foco.focus({preventScroll:true});
    window.scrollTo(0, scroll);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !event.defaultPrevented && !document.querySelector('dialog[open]')) {
      event.preventDefault();
      window.parent.postMessage('guias:volver', '*');
    }
  });
})();
