// Conserva el foco para el teclado incluso después de cerrar un diálogo.
(() => {
  const root = document.documentElement;
  const pointer = () => root.classList.add('navegacion-tactil');
  document.addEventListener('pointerdown', pointer, {capture:true, passive:true});
  document.addEventListener('touchstart', pointer, {capture:true, passive:true});
  document.addEventListener('keydown', event => {
    if (['Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key)) {
      root.classList.remove('navegacion-tactil');
    }
  }, true);
})();
