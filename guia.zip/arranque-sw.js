// Caché exclusiva de los archivos públicos incluidos en esta edición.
const base = new URL(self.registration.scope);
const prefix = 'guia-del-tcp:inicio:' + base.pathname + ':';
const current = prefix + '87471e8c6cd3d61f42a4';
const catalog = [["arranque/index.html","7d86d73f468727b02346d69fe81289c4b9d947f2bd34723e7b0a96459f1b2f70",true],["index.html","47c2c73250449a81fbaf6989ae0c26e4d408699db7792dfa3a8aa50e0ea540db",false],["guias/modo-foco.js","0653968552c2c2bdb1d67ec5f1ecf0bfd976f5a99af29e94e3e5a17e2d6a945a",false],["guias/modo-foco.css","9739a29757ee8a1837e495499f2f9f8e100e3c909d24152ac1392116180e8b5f",false],["convenio/boton-ciii.svg","527e94a22b3531e2c38fd41571cd27f472ff97b5a5dfbb35f8647511d1542bd3",false],["guias/lector-integrado.js","4370ef9b7b51ad6c8caaf8468ffebce919a9059fd1b4fdcf420e4e03130516f6",false],["guias/index.html","dde2373b2bb69be64d746c19c963ae7b87b25b001004d69744c37f2787df63c0",false],["guias/afiliacion.html","c6e3bc6d214ca40a89bc392e5dc71afc2b7a982126ed7ef82049979420c81b77",false],["app-assets/apple-touch-icon.png","88e60621856260603b841a51dbd53f1d8892e833141bb360ef9229aa3bdfd376",false],["app-assets/arranque/0dd04ca64f592b83.woff","0dd04ca64f592b83dd22edbda67500d39c0cad42516b7e7027d54383d6472979",false],["app-assets/arranque/3b9bf961c87a1670.woff","3b9bf961c87a16709b502521d6f420beba35f686c33d3383c046646e10b29cda",false],["app-assets/arranque/588cc46f74e1b18e.woff","588cc46f74e1b18e824d39cdebb11dee06abe43c06f144a33a50104d106a3ce4",false],["app-assets/arranque/6baf73226fb38905.woff","6baf73226fb38905897af9113887601146168aa9aa4d2fcd0f765cd1702ce7c7",false],["app-assets/arranque/a1a20819e8bd3cb8.webp","a1a20819e8bd3cb8e2132e1b8a2065db103d3de8eb45265477653dbb7e3e83c9",false],["app-assets/arranque/e18282d9b64d6d43.webp","e18282d9b64d6d43d2bc30199e1b3737cba3dcc7a882ff06631094b7d1b5d379",false],["app-assets/arranque/programa-1e4f961517977fa4.js","1e4f961517977fa4be85e31f7f601a801cd09e6bed5f56da0b99509e71af53a1",true],["app-assets/icon-192.png","0edec75749aea22035c6a395955ac469cad6b87cc1ea906edb738ec12ee41e98",false],["app-assets/icon-512.png","eac87f54dd09766d711dd6f4a593eb9e3d222bcbd033e492cb8c2366db2e7b28",false],["app-assets/icon-maskable.png","fb54b119046f7b2d69e63b2291534be3b2382d60de36ce41e245b2279bd47140",false],["app-assets/manifest.webmanifest","2b5a81f629a73b5da4f762f60976c3a55fe82603eacb9446d7f55a3f28cbaa5d",false],["convenio/Convenio_III.pdf","2fc788277bde251816c46362b2b76c80a4edfa4d6a22d23241937ece346c509f",false],["convenio/pdf-local.js","8b8a8d61233491e651a329bff743d80bace2d38e32cc00dbef00aa94e4ffd2d3",false],["guias/Formulario_USO_banco_en_blanco.pdf","dc253cf921c7c959e27b59f02da1d286aa02fcd29c12b872c1ae64babae34bcf",false],["guias/Formulario_USO_nomina_en_blanco.pdf","fe9a71d6740a2ece4d7ff9768b84ff640b61fd1501cd835be0bf75c375351ee2",false],["guias/III_Convenio_TCP.pdf","afed94d99970e7b1a8bdc44048ca6740aebab6897a136177580447dc556e270c",false],["recuperar.html","8837bd171b5f15327498b41f47910245d7b9ebc1aceb42757205f2eacf896e62",false],["revision/app-assets/apple-touch-icon.png","88e60621856260603b841a51dbd53f1d8892e833141bb360ef9229aa3bdfd376",false],["revision/app-assets/icon-192.png","0edec75749aea22035c6a395955ac469cad6b87cc1ea906edb738ec12ee41e98",false],["revision/app-assets/icon-512.png","eac87f54dd09766d711dd6f4a593eb9e3d222bcbd033e492cb8c2366db2e7b28",false],["revision/app-assets/icon-maskable.png","fb54b119046f7b2d69e63b2291534be3b2382d60de36ce41e245b2279bd47140",false],["revision/app-assets/inicio-ios.webmanifest","2b5a81f629a73b5da4f762f60976c3a55fe82603eacb9446d7f55a3f28cbaa5d",false],["revision/app-assets/manifest.webmanifest","2b5a81f629a73b5da4f762f60976c3a55fe82603eacb9446d7f55a3f28cbaa5d",false],["revision/arranque/index.html","9326ae63c249b1fee24defbad9880c21aaa685c5bbe2f81d90d31d8904591b30",false],["revision/index.html","5380b95e660431bbdf439b5791ac270515213f8652d256114aec0485f9663982",false],["convenio/paginas/1.webp","07f4c9aa4981cddc3ffd75dc328e7a4378759a48bdc439234d3f288f5de3253d",false],["convenio/paginas/10.webp","ad2367a90535010903c2c190ee93cabe09d819f04370be0688ade2cb3e3edd3b",false],["convenio/paginas/11.webp","757d3a0cc52284f5f5592ad2c61d8b4baa9235f5e75ce852d435b02a31471670",false],["convenio/paginas/12.webp","217755f29f145199aebb0dde36afb245b78389a872843799652846d3283dfd20",false],["convenio/paginas/13.webp","5c821e3b58528e418cab24f95c6c6d244dbd2d358553ad8d2bfd6a5992409d5c",false],["convenio/paginas/14.webp","a1b6ab5116234fa2a93e1c45ee68cb63d722caefbb44edae28e0fcabf19a2e13",false],["convenio/paginas/15.webp","178c6a3a85ae91a0293052779cb514c8119b6466a6c97be4c2b38a0de9f59281",false],["convenio/paginas/16.webp","644f9c798b75e878d3eed4266e2bf52e661480c8ec7aedb11ef371c000644352",false],["convenio/paginas/17.webp","19449e724af506cc3f5459e6a03278d1bd1e176691829c4a2fc3ca9f62f37fb9",false],["convenio/paginas/18.webp","6fbeb3fae7345a7caeffb4043b74bcb740cdde34c4f39f7ced3e5e14997d3374",false],["convenio/paginas/19.webp","3bc9572db9e9ad43887a47ff127f535990c938ccbeeb548bdf7f66ef1b19f912",false],["convenio/paginas/2.webp","da07abf7cd4a9e50902f4bf8726142c5909e759dcc821099082fcca7c6900a3e",false],["convenio/paginas/20.webp","0544bad15e61e57fcdfcecfdd0f90ac1615fc33f24d375a9fecfefd141e32e2a",false],["convenio/paginas/21.webp","b0f797a6a72d1c750ac1c8ceafdf8f9376fdcaa9ca514acc1300226d8b6f8142",false],["convenio/paginas/22.webp","a071d2e0e32e469b47177a95b858eff2208771c2640c177eeb21ea5782e5a1f0",false],["convenio/paginas/23.webp","2d87257049fd9660e11cce7e756e2678a13c8f46a81d2c61af2df561b3c2a7b5",false],["convenio/paginas/24.webp","2489a64839f65daa0b342505f03fd3968aa4f600c5665bf6dd6c936c2882e5d7",false],["convenio/paginas/25.webp","75cf4489d397f2a1c094c5665a6c961c3c5fda8cdb6d94b29c5738e24aa9d292",false],["convenio/paginas/26.webp","21e37e0c6e63674da7c30c10d53bbd7448917961d55ab57fe4af930fa9b82bda",false],["convenio/paginas/27.webp","ef38e206778f9d72928c3c9f817ab23e2ce498b4e9d9f2fa3b5c60d0c2a1ebd8",false],["convenio/paginas/28.webp","e9e39443a2728268d2a6f24a5ad4af873950b1a43f9ed766449cc77902aa1601",false],["convenio/paginas/29.webp","35371ac9c71651b5408ab794cfc97f7a9a662295ea1cad8d1590fa4fc507c651",false],["convenio/paginas/3.webp","d9e8a129765cc3d756c0ab80c113e2a33104e18f7448067e2ac63645a48cc887",false],["convenio/paginas/30.webp","a75b014e777ad1db0a1314470d8d472cffeaf92fb000015959d32a92f644806e",false],["convenio/paginas/31.webp","15d8a3a6460a20d7712ad2eddfbd5d3a9940f31aadd6034fd3de6a3da0144dc4",false],["convenio/paginas/32.webp","ba86182aee8c064ac461c2bf52ffc162b1bb1dd4e9b52e2d1a908587b453154f",false],["convenio/paginas/33.webp","9c9b8733953127745fa95f04c7f6f89f44ead128b8905c2ec769d8e3f5cf1034",false],["convenio/paginas/34.webp","4b15b509a08f68c89fd5da2e699b5d4bdcb95515cef520316deed38817ded1bd",false],["convenio/paginas/35.webp","e0dd884d1b058819a341ea8a0bcacc0fe195a8e4430389dc918b06a721eaff96",false],["convenio/paginas/36.webp","75e248806d4e998168d3a9384389f3f45f8c496254650982d2e61f11a965ca6e",false],["convenio/paginas/37.webp","4b7af4dd4023448f93d49accb1b3406e25ec2fa88d8878f6911ecba19f24816c",false],["convenio/paginas/38.webp","1e70421943f733ccecfe670c4345aae78a2fb8cb96efcbe9d9450c5490d62ce0",false],["convenio/paginas/39.webp","dde46d6c251d3a5869c2c22253d246156c77ee5baaa1c23fcf89ca78313086b5",false],["convenio/paginas/4.webp","afd8748e02df67096d8d31cf79cc4212f43836f3ca08516e771c253e3e214fdc",false],["convenio/paginas/40.webp","e8bd93e8887fafdf3907ed0eb2b11e16b89e2ef40a6be6efbcee4ca0d8bc4c74",false],["convenio/paginas/41.webp","1114cb8a8146df807c77f44b7027449bf4c494d8df00fe7b7288d9b8f8829ad3",false],["convenio/paginas/42.webp","10b77bbc116e7522914a8b8bc27b17ef7a3bb3509e5d2312d718d0aca3e896cd",false],["convenio/paginas/43.webp","9953558610b722f903a6df75a3d1f7e6f10ad204c78d35bcc36c15d6493eba6f",false],["convenio/paginas/44.webp","c6eb562c379142f3230f018eab127681941c99418cf306b3eb802fde4e740ac7",false],["convenio/paginas/45.webp","186c7f8f94d31b87baf4ecabddd5018927bdaef86d9941d8f26195ad9a30ca4f",false],["convenio/paginas/46.webp","e521aca0e4f81b32c5e08efa22d267b6787c973ccdf534ff1dbad4ee59313959",false],["convenio/paginas/47.webp","f2e8a77fe1c31e8ab31a200a7fe371d9008c598b4978eb6b4beafd1affb8139a",false],["convenio/paginas/48.webp","bb91b1805c626b045d9957f9759b99c504a27ae0e823692dfdd3a707d383b5c8",false],["convenio/paginas/49.webp","b78fa006ffb954b647151a579be72bb24ca812e7d271114974ccb49a6a13d844",false],["convenio/paginas/5.webp","df59ca091ffd5dc08f3aba97549681a49c2e2b3ca96185e38e489649c73127a7",false],["convenio/paginas/50.webp","4885db5fe2cf7f1cd4db12343e0874f087054fe3f40be39e9b6bc7517d56ee6a",false],["convenio/paginas/51.webp","92044aad35a1757aafab9f542544142961a4faf7eac1e83b3b7a93438bb720ea",false],["convenio/paginas/52.webp","accf1a7d46e1e1ad743d43cdf1951aad92602e3e0f8e11201e2a7a5c271c896d",false],["convenio/paginas/53.webp","266ae4bd1721cae23f3dc59e15404df34a5476125e21f919d895480cb7230079",false],["convenio/paginas/54.webp","c38c6e5371cffe994d0bc0830593709474e6e6af2752b348249808ddd732e60c",false],["convenio/paginas/55.webp","216d0cceb5567009433378ddf56c42b9c794d8dce4a12aa938a794e17fa81450",false],["convenio/paginas/56.webp","9c3548e99817d852c029bb6900e28b554ce867e5d16a99ea2fd1bedd02b73a46",false],["convenio/paginas/57.webp","f4fb6791f0d4011f252c349e63bb021086f0a671c2478cdf974a9080b213be91",false],["convenio/paginas/58.webp","58fecefba83dd28ab57cc6d17bfb3b63bfc238a64f287b0b3d2e63adbdfc9881",false],["convenio/paginas/59.webp","a7f5108be3d85063623d1210b75d3f0c4cb8955c865aad5bf89791aaff0c9051",false],["convenio/paginas/6.webp","3f66df00a97cf91c3e54b24c3a72a745ea3476824052b5379d63645ccd751d19",false],["convenio/paginas/60.webp","03d2f9f3514653e378cdefafd29ece3783b1f654c0ac10b471aad60146b5c349",false],["convenio/paginas/61.webp","bd8bf68ac2f8c3db5c6415457e8ae177f267852602a495d7d9bc750042c4756a",false],["convenio/paginas/62.webp","579f2dd49fa3f71a4c4ffe68dcdf05d3b07ab2e5dfcfadd60d9622f422a36945",false],["convenio/paginas/63.webp","15380aeec898499fc81c4da02c921110806e1623ab54c17998ea698846189b21",false],["convenio/paginas/64.webp","be738ca6cc9082a01bb5054aecf8630b2502138a3a08012bb01806b2079bbb60",false],["convenio/paginas/65.webp","fa7dbd5834f58604347a92b68157380edd82414f602c4d390170974c2d8ea551",false],["convenio/paginas/66.webp","02dab3528fe568bef99352003d2158ff602ee96e424a3dbbc3440256ece68659",false],["convenio/paginas/67.webp","1dc6eb43e831573cc20160f9dfd50aa58fe99e8fb55faf6df82950fe12029389",false],["convenio/paginas/68.webp","6d3350d8428281beebb4bb398d64db61be7197d4e98639bc2d9353d323857971",false],["convenio/paginas/69.webp","7ecf7f17d87f46f4895a7866b51e2c52a2f9f02de8c5ec187adf5cba2e014ce9",false],["convenio/paginas/7.webp","502c7e3a9e706e2f8b572f3c77746d4e3bca5266a959bbe0309f8276c53efb0e",false],["convenio/paginas/70.webp","0dd22f34b193e171a27430d9f707ae6f650d363cda199d1e71229ce9baf54ce9",false],["convenio/paginas/71.webp","3363f7be17f58c70719587958e1a01f797d44ed51505e31722d67e0c9147344f",false],["convenio/paginas/72.webp","0d5773b869c1ae26241360d0958f4bc3190b2c5c459131b112f4b513e6674557",false],["convenio/paginas/73.webp","50814a3a045ac46831ba6a33aa4d8197477655093e406d448f2a3ad892d64a0c",false],["convenio/paginas/74.webp","042eca9ebe022bd4b7f43c9e6c52a62c1e4ebbbbae119b2f911b39a159f11702",false],["convenio/paginas/75.webp","16b533baab339232eb341e7c9ed1d7e5d759dfc8f7569b2ff602def59b35d1e9",false],["convenio/paginas/76.webp","a934b16bd16e1e9ea8ef4d1293207faf2b2df5b0a8c4e56e755b962798fcd670",false],["convenio/paginas/77.webp","0e208e625167ebb92ecd5d65ef55c611e97e0a4e7f449d7dd418443c2834c22d",false],["convenio/paginas/78.webp","ee57420b3b6ec5312f49015f858cf3f7a229ae204cb74e364dc08ffe5567e95e",false],["convenio/paginas/79.webp","1877e865e973b162ad1f1245de8c899477c98780a3b296ea246590f717eb76c9",false],["convenio/paginas/8.webp","87176649c59b441334c470beb57438dc376b1e0b6bc00d9b32adab64dccd7ebf",false],["convenio/paginas/80.webp","f0c18e9836bc2488874d516ed6a9f8de7bc5ccc9b2503462437993d4b0a33f5c",false],["convenio/paginas/81.webp","cf313f08c0d3e87c33756ffc551685a5487b1b5502d3e2214032048fc6ca43e6",false],["convenio/paginas/82.webp","7321a5afa99858357fa3e28680ed760008f3f0209efad9011e03b008217300a1",false],["convenio/paginas/9.webp","568d6aafcbde3adf0a8a4a28d0a26315b76447af4b1faedde008418bc7c1ed33",false],["guias/lector-0ba817d981dcd897.js","0ba817d981dcd897e25be0eef97298da0b2a9f21dbd884e4b9901becf709d6d4",false],["guias/paginas/1.webp","b2327fcc444d03d37c160f2f2fab0e7e6e9e389aac71413d38eaef6601d07f23",false],["guias/paginas/10.webp","25399377c017b9e46dc7f1f60e865dbc6ddfe3f2ed383ea2698ea59ca8d9c8a5",false],["guias/paginas/11.webp","f020de60e5e504338e88faaac28a2ba4963ac25dfc4eb9e6e4ac189da157b269",false],["guias/paginas/12.webp","9ec8fd7b7598f3ccded895981833d7a37f0b3e9e0939b5dc291d1d93cf3ee595",false],["guias/paginas/13.webp","99f853c328b1251b7c9036b21c15c17367e137d8116e17120ca4d9f8028b4bc5",false],["guias/paginas/14.webp","12be01a9540dbdce21dfa47c9aa180f32e719ef0e3d07d0a25d8a872ab52617b",false],["guias/paginas/15.webp","d235c9edf04f4efc952b458324f8f0fccb07d134724989f7d04e2b6b2ec0a431",false],["guias/paginas/16.webp","999220e7044d76164dbbc78868dd586446b39edfcb58b09b156fcffc9958751f",false],["guias/paginas/17.webp","24686c95926eb6e55a696f68aa6ad3c99a41eae6d3f5f6f3d11b433705433f85",false],["guias/paginas/18.webp","13cc96b430c5ed221c28af6658b62d3cc6eb2f281c9fafb8c3cccc9a639dbc0d",false],["guias/paginas/19.webp","42a523b13fd29045b58a4295f78e2b19566c3ffb3927e3eabcbb6debefe802f2",false],["guias/paginas/2.webp","4571260f53b2c0c5d9fd537fe756909c2035103b8e2bfb82114e4c0012546c10",false],["guias/paginas/20.webp","6bbf09b2b965bc11d919bc8882b53cc83cf88c483034e161d50bc3de39408449",false],["guias/paginas/21.webp","6c30c54bf779e643e57fe20d1360bb6604ed2a43bbeab817ffadac1f3e513899",false],["guias/paginas/22.webp","2a64cbe5a3246deab7651d430abb9cfe9d2b5c2c66cb9dc3448299281bf8bb1a",false],["guias/paginas/23.webp","7e6913fb653e0728bb9fb229108cb18db60874ef09d88c5bfd3ad905cdf2f6c7",false],["guias/paginas/24.webp","4d27c18c5332e7e5a32b6efac31c086df97d12ac1e16372d31cea49ed96ec18a",false],["guias/paginas/25.webp","bee98d09036c58b47995c5311a5e7ae259b3bb168f838957e1188e2b5e346caa",false],["guias/paginas/26.webp","4d8dee6b18418232e696e6c6dd3f2e4f7bf3bfcdd3f1846f1461db0a9e50b421",false],["guias/paginas/27.webp","e130822c66dae6a8936dfa3c6ba1bde34588b980f1369afb1351970b66c7dcd6",false],["guias/paginas/28.webp","ea4ed24976751c462ba923c64f3ce0a66583f0fdd260843c49f2d3b1c8152e9a",false],["guias/paginas/29.webp","4c23cdfd6b93e97deb09dfbe8adbead32d1b71204184b423bad19008eb5d7113",false],["guias/paginas/3.webp","1f42aa422b0dae3e5dcb659999fc6a4416043babcf4b5a5a580dfcb870c008fd",false],["guias/paginas/30.webp","f99444d3d8c339ce672a408e81f8dab7e4b75a5123cf576c12dad6c71860184a",false],["guias/paginas/31.webp","6e330cf740bbd42b4331321a10935b47348d01e3ccdf5b4ac9dc77df2f5ee12d",false],["guias/paginas/32.webp","4be652b7f65598bb3bf8b7e47d1aee9580403324dde608527dd8d9fb0bd5db2a",false],["guias/paginas/33.webp","3bc123b3aa88ea54d81b11d5e705522a83faacc219dea66b5293c411850abab7",false],["guias/paginas/34.webp","32d4e73d37adc3b34bf6abaaf672be2c9c5b74964ad3d7bd598654849bf9c1be",false],["guias/paginas/35.webp","6533b9a72c173b283c1ef6420705f5ea414b8e190bc8a3e58bdb6bea00053d6a",false],["guias/paginas/36.webp","96cd18988c951c911fb2b9fe698499871528b62a2e2d75e2782643862eeb5bd5",false],["guias/paginas/37.webp","ceef88ee1287b2d1053113fc7b7ae2f1d6c691dbb962fad4a452c79e3ce10f35",false],["guias/paginas/38.webp","007cead157ba5bf44bde8b95c6f49f25f7470072230b6ab0876a8904ff5394b0",false],["guias/paginas/39.webp","01f278747233b3a458ad45f40aef4e4cdd28fdac9a528205bdafd98b36adb570",false],["guias/paginas/4.webp","c1d80d4b4cd7a1e37c55a8b3f142bd4c6872b01bbe55a9a47edfbd8e879b5f7b",false],["guias/paginas/40.webp","b8f30b1d45c20e4e08867e24e94c661566a0e47f6dcf27d05e1bdfe469b827ed",false],["guias/paginas/41.webp","2bdeb88dd12878b80eeedae297dbc2f5dfc6f20e615ba95595c3015359281a6a",false],["guias/paginas/42.webp","290471386d8721d25b5a168d31bdcaf3bb0b644969fd66ae67e81b6c2e3443c9",false],["guias/paginas/43.webp","c25cefbfa39ceaa7be247585a0e675855d7e6dd5032b052e0ec797fbd3fb586a",false],["guias/paginas/44.webp","67c228deae958eb6670cfd1e6df5a12faf212ff7d59d58a374dbea8fedeaa08e",false],["guias/paginas/45.webp","48b64cbf15d3a3b1326b98630619b4c526b11392a0d70c81d387735edaac60e4",false],["guias/paginas/46.webp","9ea0bec5485be25fbe92815441e2a7e72b9d63da4dbd49d8b18f457fd3e29a53",false],["guias/paginas/47.webp","7829d2b021bea46efe8e22fb6a08b4defb16ca969b31810caa68d2878f59555a",false],["guias/paginas/48.webp","a07fa11cc6b41d48f2f7bfd487e33b82497209e29a83e34f8eddc0fe76606314",false],["guias/paginas/49.webp","0088bf942edb9cc54e2127fd315c9aa370b6de55c154d9b98ca37ad4cb2d9d08",false],["guias/paginas/5.webp","2ea01a27efcafccf43dc8d774db9870b47da3c592b213ef4c9b2b3048344e447",false],["guias/paginas/50.webp","ef7ab5bc3e17529b20d155fe42d5fc36b3afae204c56065e8d994a25aa30b7f4",false],["guias/paginas/51.webp","563fca59c05fb803bd39524bc68eb03cc7992f758b44617462931efe58da51d4",false],["guias/paginas/52.webp","e5d89f2569684977d286ab7cbde6df767302fe3ebe8c9f05eb12c3b8f74adf62",false],["guias/paginas/53.webp","26f53f0d9b2a82bfd84d9ec532d8965ce52b85d110d15815748f506b4b3f50f7",false],["guias/paginas/54.webp","c9f692e882347111365a3eaa471a8a28ae61434390d1552d3cebc67b5b3a9c1d",false],["guias/paginas/55.webp","3c37953caf8fb735a60c6683ae3b7dab0b67dfdb5966cedb99b3f989f7449654",false],["guias/paginas/56.webp","ee2026b1eb52a6c9a81d238e119202479194eaa29d1f4284152ba8a6b1714ca0",false],["guias/paginas/57.webp","1639b2e9d5efaa37f7b46148e5f88d5d9948e67a90162a6e5af6d13eac17f8d3",false],["guias/paginas/58.webp","69d2800f489a3681174016da4724aa679d06c90b8c60b3cd358832ebb1e8a0cd",false],["guias/paginas/59.webp","83f2a0b89b591f949b0c6442f6a8716b454d55c52ddd64c257b801a4577c1c1b",false],["guias/paginas/6.webp","57430df05d066c1e70e69dd9ee4535d510146ae5e32fe36aba0a103712d6bb57",false],["guias/paginas/60.webp","2ca0aa69b759fe8a87c7eabfc6057b41109f9e8af79510a3a3337bb952d8489e",false],["guias/paginas/61.webp","34161bd2c150575f623104011ab8750bb5856bf8ea5b5c6eb3b9223c8593257d",false],["guias/paginas/62.webp","c4222c9a21595d2a2fccd76faab3039328a387efa50ec05ea089db45e44392cf",false],["guias/paginas/63.webp","e9a69719e15b829ad02aeaebd08cb08e9d2c7474dac81ee3ca478f94693e7183",false],["guias/paginas/64.webp","2eab42a3f0e5193d8845cc492fde0e39b3b04efd31293fc707e5a33e5cba26bb",false],["guias/paginas/65.webp","ef474f2230d7e100c53e56e54b19c81a985628b8c2c6d27c50fe20f07a8ad155",false],["guias/paginas/66.webp","aa0e0132a80c52e9bbe72465e9cf58da07c18c035cb577f99a796e32d23ea2d9",false],["guias/paginas/67.webp","9c928357c82010e01680999defd3260521db6da7f180ddf01c84164ee0a9b22a",false],["guias/paginas/68.webp","06287641c6a4485d6c6650c49f4620889b5287d1efd619b36e551884f7166102",false],["guias/paginas/69.webp","4b974fc1d5696efaaba04a88c40afdaeab34b04f2746859c152215b500bead8d",false],["guias/paginas/7.webp","6abe56b2117071a10160b1c2eaaed818a95321a93d6f91a37227b00ff5832897",false],["guias/paginas/70.webp","cfa7e6b3cbbd29412f04311e4b5222ca5dcf1e7cf5d911fd9587faf1a756f329",false],["guias/paginas/71.webp","04f69261aa5347e427323fdbd2cadb10b58ca0de6086dbf5b9feaced62e8f178",false],["guias/paginas/72.webp","39d328334a163f11b54c814628534f986349ecbdb88a686a43975a54a96111d8",false],["guias/paginas/73.webp","7a713ea9231e938660562f37cb2040b2eefd3db6820c1b4a1608d8f08757fed4",false],["guias/paginas/74.webp","b7358c3703e7d3765c173ca2b01b6f02a1dfe5bf6696a7eb894239fd0feeb65b",false],["guias/paginas/75.webp","432b332f4035f88ddfd3424321733f75e1e7fdfa881474825eb07dc3cecc9cb3",false],["guias/paginas/76.webp","06b17787954f4b8e4153fcd19b2fbabce52a7de95ca4b05c5c3940390f9aa7ff",false],["guias/paginas/77.webp","2ec0bcab94e465a6b612ae5d994a9b4b4f83b68c06685c9458b47a73c12b2718",false],["guias/paginas/78.webp","c76db904cae71e8c8d5324a152f8efbd22eb4f3dacf4dee3677f097214d139de",false],["guias/paginas/79.webp","1b52d0ac0a0d758c869eabcfc2875f525f76275dc6b4a25802a8068e1cbf0b71",false],["guias/paginas/8.webp","b3e29db13a8ec1c582a5474821af975d0b994a33186ede59cec9b6c45739a067",false],["guias/paginas/80.webp","5f3d2d1c0aca4f9ae059d351d61b30eda7a32c43441db37aa2a329f1f3a4898c",false],["guias/paginas/81.webp","437edc5a7ec614a7c9a54f3c7a735c7840d4e8b5f0cb72a91fb290fd6c68d31c",false],["guias/paginas/82.webp","96c1646fe8080967d5779a8cf7988bfc143ee5fe0e124c935b6e773c552a786d",false],["guias/paginas/9.webp","d58c2b5573d66c4c7fefce05b4e8e9488f5b85215bd55e7c3b9c5f859d524bc0",false]];
const urlFor = path => new URL(path, base).href;
const files = new Map();
for (const [path, digest, core] of catalog) {
  const entry = {path, digest, core};
  files.set(urlFor(path), entry);
  if (path.endsWith('index.html')) {
    const directory = path.slice(0, -'index.html'.length);
    files.set(urlFor(directory), entry);
    if (directory) files.set(urlFor(directory.slice(0, -1)), entry);
  } else if (path.endsWith('.html')) {
    files.set(urlFor(path.slice(0, -5)), entry);
  }
}
const home = files.get(urlFor('arranque/'));
const legacy = new Set(['Simulador_III_Convenio', 'Simulador_USO_III_Convenio', 'Simulador_USO_III_Convenio_TCPs']
  .flatMap(name => [urlFor(name), urlFor(name + '.html')]));
const canonical = entry => urlFor(entry.path.replace(/index\.html$/, ''));
const keyFor = entry => urlFor(entry.path);
const downloads = new Set(["guias/III_Convenio_TCP.pdf", "convenio/Convenio_III.pdf", "guias/Formulario_USO_nomina_en_blanco.pdf", "guias/Formulario_USO_banco_en_blanco.pdf"]);
async function cachePublic(cache, entry) {
  const url = canonical(entry);
  const response = await fetch(url, {credentials:'omit', cache:'reload', redirect:'follow', signal:AbortSignal.timeout(30000)});
  if (response.status !== 200 || files.get(response.url) !== entry || new URL(response.url).origin !== base.origin) {
    throw Error('Archivo público no disponible');
  }
  const bytes = await response.arrayBuffer();
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  const hex = Array.from(new Uint8Array(hash), n => n.toString(16).padStart(2,'0')).join('');
  if (hex !== entry.digest) throw Error('El archivo no coincide con esta edición');
  // Conserva el tipo del archivo y su nombre de descarga, incluso si el servidor lo comprimió.
  const headers = new Headers(response.headers);
  headers.delete('content-encoding');
  if (downloads.has(entry.path)) {
    headers.set('Content-Disposition', 'attachment; filename="' + entry.path.split('/').pop() + '"');
  }
  headers.set('content-length', String(bytes.byteLength));
  await cache.put(keyFor(entry), new Response(bytes, {headers}));
}
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(current);
  // El simulador se puede abrir en cuanto se guardan la portada y su programa.
  await Promise.all(catalog.filter(row => row[2]).map(([path]) => cachePublic(cache, files.get(urlFor(path)))));
  await self.skipWaiting();
})()));
let filling, complete = false, nextAttempt = 0, retryRequested = false;
async function fill() {
  const cache = await caches.open(current);
  const existing = new Set((await cache.keys()).map(req => req.url));
  const missing = catalog.map(([path]) => files.get(urlFor(path))).filter(entry => !existing.has(keyFor(entry)));
  let cursor = 0, missed = false, consecutiveFailures = 0;
  async function run() {
    while (cursor < missing.length && consecutiveFailures < 6) {
      const entry = missing[cursor++];
      try { await cachePublic(cache, entry); consecutiveFailures = 0; }
      catch { missed = true; consecutiveFailures++; }
    }
  }
  await Promise.all([run(), run(), run()]);
  if (missed) { nextAttempt = Date.now() + 15000; return; }
  complete = true;
  for (const name of await caches.keys()) if (name.startsWith(prefix) && name !== current) await caches.delete(name);
}
function prepare(retry = false) {
  if (complete) return Promise.resolve();
  if (filling) {
    if (retry) retryRequested = true;
    return filling;
  }
  if (!retry && Date.now() < nextAttempt) return Promise.resolve();
  filling = (async () => {
    do {
      retryRequested = false;
      try { await fill(); }
      catch { nextAttempt = Date.now() + 15000; }
    } while (!complete && retryRequested);
  })().finally(() => { filling = undefined; });
  return filling;
}
self.addEventListener('activate', event => event.waitUntil(self.clients.claim().then(() => prepare())));
self.addEventListener('message', event => {
  if (event.data === 'tcp-preparar') event.waitUntil(prepare(true));
});
function servedKey(uri) {
  if (!uri.search) return uri.href;
  if (!/^\?v=\d+$/.test(uri.search) || !/\/app-assets\/(?:[^/]+\.webmanifest|[^/]+\.png)$/.test(uri.pathname)) return null;
  uri.search = '';
  return uri.href;
}
async function stored(entry) {
  return (await caches.open(current)).match(keyFor(entry));
}
function boundedRange(response, range) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match || !(match[1] || match[2])) return response;
  return response.arrayBuffer().then(buffer => {
    const size = buffer.byteLength;
    const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), size-1) : size-1;
    if (start > end || start >= size) return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+size}});
    const headers = new Headers(response.headers);
    headers.set('Content-Range', 'bytes '+start+'-'+end+'/'+size);
    headers.set('Content-Length', String(end-start+1));
    headers.set('Accept-Ranges','bytes');
    return new Response(buffer.slice(start,end+1),{status:206,headers});
  });
}
async function offlinePage(key, entry) {
  const page = entry && await stored(entry);
  if (page) {
    if (entry.path.endsWith('/index.html') && key === canonical(entry).slice(0,-1)) return Response.redirect(canonical(entry),302);
    return page;
  }
  if (!entry || ['', 'index.html','revision/index.html','revision/arranque/index.html'].includes(entry.path)) {
    if (await stored(home)) return Response.redirect(canonical(home),302);
  }
}
async function openPage(req, key, entry) {
  const cached = offlinePage(key, entry);
  const network = fetch(req).then(async response => {
    if (response.status >= 500 || [408,429].includes(response.status)) return (await cached) || response;
    return response;
  }).catch(async error => { const page = await cached; if (page) return page; throw error; });
  let timer;
  const slow = new Promise(resolve => {
    timer = setTimeout(() => resolve(cached.then(page => page || network)), 450);
  });
  try { return await Promise.race([network, slow]); }
  finally { clearTimeout(timer); }
}
self.addEventListener('fetch', event => {
  const req = event.request, uri = new URL(req.url);
  if (req.method !== 'GET' || uri.origin !== base.origin || req.headers.has('authorization')) return;
  const key = servedKey(uri), entry = files.get(key);
  if (!entry && !legacy.has(key)) return;
  if (req.mode === 'navigate' && (!entry || entry.path.endsWith('.html'))) {
    event.respondWith(openPage(req, key, entry));
    event.waitUntil(prepare());
  } else if (entry) {
    event.respondWith((async () => {
      const saved = await stored(entry);
      if (!saved) return fetch(req);
      return req.headers.has('range') ? boundedRange(saved, req.headers.get('range')) : saved;
    })());
  }
});
