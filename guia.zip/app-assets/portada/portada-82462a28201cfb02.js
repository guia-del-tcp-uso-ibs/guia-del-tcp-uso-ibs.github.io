(() => {
  'use strict';
  const banner = document.querySelector('.sky-banner[data-portada]');
  if (!banner) return;

  // La rotación solo afecta a los tres rótulos decorativos de esta cabecera.
  const titles = [...banner.querySelectorAll('.frase-portada')];
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let titleIndex = 0;
  let titleTimer;
  function showTitle(index) {
    titles[titleIndex].classList.remove('actual');
    titleIndex = index;
    titles[index].classList.add('actual');
  }
  function restartTitles() {
    clearInterval(titleTimer);
    if (document.hidden || reducedMotion.matches) {
      showTitle(0);
    } else {
      titleTimer = setInterval(() => showTitle((titleIndex + 1) % titles.length), 5000);
    }
  }
  document.addEventListener('visibilitychange', restartTitles);
  reducedMotion.addEventListener('change', restartTitles);
  restartTitles();

  const assetDirectory = new URL('.', document.currentScript.src);
  const photos = ['amanecer', 'manana', 'tarde', 'atardecer', 'ultimas-luces', 'noche', 'aurora'];
  const minute = 60000;
  const day = 1440 * minute;
  const rad = Math.PI / 180;
  const latitude = 40.4168 * rad;
  const longitude = -3.7038;
  const { sin, cos, tan, asin, acos } = Math;

  // Coordenadas solares aparentes y ecuación del tiempo. Se trabaja en UTC:
  // el instante de cada transición en Madrid es el mismo en cualquier dispositivo.
  function solarParameters(instant) {
    const t = (instant / day + 2440587.5 - 2451545) / 36525;
    const meanLongitude = ((280.46646 + t * (36000.76983 + .0003032 * t)) % 360) * rad;
    const anomaly = (357.52911 + t * (35999.05029 - .0001537 * t)) * rad;
    const eccentricity = .016708634 - t * (.000042037 + .0000001267 * t);
    const correction = sin(anomaly) * (1.914602 - t * (.004817 + .000014 * t))
      + sin(2 * anomaly) * (.019993 - .000101 * t) + sin(3 * anomaly) * .000289;
    const omega = (125.04 - 1934.136 * t) * rad;
    const apparentLongitude = meanLongitude + (correction - .00569 - .00478 * sin(omega)) * rad;
    const tilt = (23 + (26 + (21.448 - t * (46.815 + t * (.00059 - .001813 * t))) / 60) / 60
      + .00256 * cos(omega)) * rad;
    const y = tan(tilt / 2) ** 2;
    const equation = 4 / rad * (y * sin(2 * meanLongitude) - 2 * eccentricity * sin(anomaly)
      + 4 * eccentricity * y * sin(anomaly) * cos(2 * meanLongitude)
      - .5 * y * y * sin(4 * meanLongitude) - 1.25 * eccentricity ** 2 * sin(2 * anomaly));
    return { equation, declination: asin(sin(tilt) * sin(apparentLongitude)) };
  }

  function solarEvent(date, direction, depression = 0) {
    let instant = date + day / 2;
    for (let i = 0; i < 4; i++) {
      const { equation, declination } = solarParameters(instant);
      const angle = direction === 0 ? 0 : acos(
        (cos((90 + depression) * rad) - sin(latitude) * sin(declination))
        / (cos(latitude) * cos(declination))
      ) / rad;
      instant = date + (720 - 4 * longitude - equation + direction * 4 * angle) * minute;
    }
    return instant;
  }

  function boundaries(date) {
    const sunset = solarEvent(date, 1, .833);
    const dusk = solarEvent(date, 1, 6);
    const nextDawn = solarEvent(date + day, -1, 6);
    return [
      solarEvent(date, -1, 6), solarEvent(date, -1, .833) + 30 * minute,
      solarEvent(date, 0), sunset - 45 * minute, sunset, dusk, (dusk + nextDawn) / 2, nextDawn
    ].map(Math.round);
  }

  let solarDay;
  function phaseAt(now) {
    if (!solarDay || now < solarDay[0] || now >= solarDay[7]) {
      const today = Math.floor(now / day) * day;
      solarDay = boundaries(today);
      if (now < solarDay[0]) solarDay = boundaries(today - day);
    }
    const next = solarDay.findIndex(bound => bound > now);
    return { name: photos[next - 1], until: solarDay[next] };
  }

  let timer;
  let requested = '';
  function updatePhoto() {
    clearTimeout(timer);
    if (document.hidden) return;
    const now = Date.now();
    const phase = phaseAt(now);
    if (requested !== phase.name) {
      banner.style.removeProperty('--foto-portada');
      requested = phase.name;
      const candidate = new Image();
      candidate.decoding = 'async';
      candidate.onload = () => {
        if (requested === phase.name && Date.now() < phase.until) {
          banner.style.setProperty('--foto-portada', 'url("' + candidate.src + '")');
        }
      };
      candidate.onerror = () => {
        if (requested !== phase.name) return;
        banner.style.removeProperty('--foto-portada');
        requested = '';
      };
      candidate.src = new URL(phase.name + '.webp', assetDirectory).href;
    }
    timer = setTimeout(updatePhoto, Math.max(1, phase.until - Date.now()));
  }
  document.addEventListener('visibilitychange', updatePhoto);
  window.addEventListener('pageshow', updatePhoto);
  window.addEventListener('online', updatePhoto);
  updatePhoto();
})();
